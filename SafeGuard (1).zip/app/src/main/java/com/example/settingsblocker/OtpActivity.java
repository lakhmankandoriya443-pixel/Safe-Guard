package com.example.settingsblocker;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.*;

public class OtpActivity extends Activity {
    EditText in;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Prefs.hasPin(this)) { finish(); return; }
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(48, 120, 48, 48);
        TextView h = new TextView(this); h.setTextSize(22); h.setText("Settings locked hai"); l.addView(h);
        TextView m = new TextView(this); m.setPadding(0, 24, 0, 24);
        m.setText("Bhai ko bulao. PIN sirf wahi daal sakta hai."); l.addView(m);
        in = new EditText(this); in.setHint("PIN");
        in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); l.addView(in);
        Button ok = new Button(this); ok.setText("Unlock");
        ok.setOnClickListener(v -> verify()); l.addView(ok);
        setContentView(l);
    }
    void verify() {
        if (Prefs.checkPin(this, in.getText().toString().trim())) {
            Prefs.unlock(this);
            startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            finish();
        } else Toast.makeText(this, "Galat PIN", Toast.LENGTH_SHORT).show();
    }
    @Override public void onBackPressed() {
        startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }
}
