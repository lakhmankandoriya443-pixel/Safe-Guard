package com.example.settingsblocker;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.*;

public class MainActivity extends Activity {
    @Override protected void onResume() { super.onResume(); build(); }
    Button btn(String t) { Button b = new Button(this); b.setText(t); return b; }

    void build() {
        boolean hasPin = Prefs.hasPin(this);
        boolean canEdit = !hasPin || Prefs.unlocked(this);
        boolean admin = ((DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE))
            .isAdminActive(new ComponentName(this, AdminReceiver.class));
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean acc = en != null && en.contains(getPackageName() + "/" + GuardService.class.getName());

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(48, 100, 48, 48);
        TextView h = new TextView(this); h.setTextSize(24); h.setText("Safe Guard"); l.addView(h);
        TextView st = new TextView(this); st.setPadding(0, 24, 0, 24);
        st.setText("Device admin: " + (admin ? "ON" : "OFF") + "\nAccessibility: " + (acc ? "ON" : "OFF")
            + "\nPIN: " + (hasPin ? "set (locked)" : "NAHI"));
        l.addView(st);

        EditText pin = new EditText(this); pin.setHint("Bhai ye PIN set kare (4+ digit)");
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setEnabled(canEdit); l.addView(pin);
        Button save = btn(hasPin ? "PIN badlo" : "PIN save karo"); save.setEnabled(canEdit);
        save.setOnClickListener(v -> {
            String s = pin.getText().toString().trim();
            if (s.length() < 4) { Toast.makeText(this, "Kam se kam 4 digit", Toast.LENGTH_SHORT).show(); return; }
            Prefs.setPin(this, s); Prefs.lock(this); build();
        });
        l.addView(save);

        Button b1 = btn("1. Device admin ON karo (uninstall rokne ke liye)");
        b1.setOnClickListener(v -> startActivity(new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class))));
        l.addView(b1);
        Button b2 = btn("2. Accessibility ON karo (Safe Guard chuno)");
        b2.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        l.addView(b2);
        TextView n = new TextView(this); n.setPadding(0, 24, 0, 0);
        n.setText("Sabse last me bhai se PIN set karwao. PIN bhai ko hi pata hona chahiye. Uske baad Settings bina PIN ke nahi khulegi.");
        l.addView(n);
        if (hasPin && !Prefs.unlocked(this)) {
            Button u = btn("PIN se unlock karo");
            u.setOnClickListener(v -> startActivity(new Intent(this, OtpActivity.class)));
            l.addView(u);
        }
        ScrollView sv = new ScrollView(this); sv.addView(l); setContentView(sv);
    }
}
