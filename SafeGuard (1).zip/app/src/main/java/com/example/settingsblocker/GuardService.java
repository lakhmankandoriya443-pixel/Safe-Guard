package com.example.settingsblocker;
import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

public class GuardService extends AccessibilityService {
    // Settings aur uninstall screens: OTP ke bina nahi khulengi
    static final Set<String> GUARDED = new HashSet<>(Arrays.asList(
        "com.android.settings", "com.android.settings.intelligence",
        "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller", "com.miui.packageinstaller"));
    // Adult content ke words / sites (word-boundary match, taaki galat block kam ho)
    static final Pattern BAD = Pattern.compile(
        "\\b(porn\\w*|xxx|nsfw|xvideos\\w*|xnxx\\w*|xhamster\\w*|redtube|youporn|brazzers|onlyfans|hentai|"
        + "erotic\\w*|sex ?videos?|sexy ?videos?|nude ?(pics|photos|videos)|nudes|chudai|desi ?sex|"
        + "bhabhi ?sex|camgirls?|live ?sex|adult ?videos?|blue ?film)\\b", Pattern.CASE_INSENSITIVE);
    long lastScan = 0, lastGuard = 0;

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        CharSequence pk = e.getPackageName();
        if (pk == null) return;
        String pkg = pk.toString();
        if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui")) return;
        long now = SystemClock.uptimeMillis();

        if (GUARDED.contains(pkg)) {
            if (Prefs.hasPin(this) && !Prefs.unlocked(this) && now - lastGuard > 3000) {
                lastGuard = now;
                performGlobalAction(GLOBAL_ACTION_HOME);
                Intent i = new Intent(this, OtpActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
            return;
        }
        if (now - lastScan < 800) return; // battery bachane ke liye
        lastScan = now;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        StringBuilder sb = new StringBuilder();
        scan(root, sb, 0);
        if (BAD.matcher(sb).find()) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            startActivity(new Intent(this, BlockActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }
    }

    private void scan(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || depth > 25 || sb.length() > 8000) return;
        CharSequence t = n.getText();
        if (t != null) sb.append(t).append(' ');
        CharSequence d = n.getContentDescription();
        if (d != null) sb.append(d).append(' ');
        for (int i = 0; i < n.getChildCount(); i++) scan(n.getChild(i), sb, depth + 1);
    }

    @Override public void onInterrupt() {}
}
