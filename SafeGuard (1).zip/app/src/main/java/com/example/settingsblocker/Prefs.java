package com.example.settingsblocker;
import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;
class Prefs {
    static final long UNLOCK_MS = 5 * 60 * 1000;
    static SharedPreferences p(Context c) { return c.getSharedPreferences("sg", Context.MODE_PRIVATE); }
    static String hash(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(("sg" + s).getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
    static boolean hasPin(Context c) { return !p(c).getString("pin", "").isEmpty(); }
    static void setPin(Context c, String s) { p(c).edit().putString("pin", hash(s)).apply(); }
    static boolean checkPin(Context c, String s) { return hasPin(c) && hash(s).equals(p(c).getString("pin", "")); }
    static boolean unlocked(Context c) { return System.currentTimeMillis() < p(c).getLong("until", 0); }
    static void unlock(Context c) { p(c).edit().putLong("until", System.currentTimeMillis() + UNLOCK_MS).apply(); }
    static void lock(Context c) { p(c).edit().putLong("until", 0).apply(); }
}
