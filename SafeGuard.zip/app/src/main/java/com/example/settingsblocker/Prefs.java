package com.example.settingsblocker;
import android.content.Context;
import android.content.SharedPreferences;
class Prefs {
    static final long UNLOCK_MS = 5 * 60 * 1000, OTP_MS = 5 * 60 * 1000;
    static SharedPreferences p(Context c) { return c.getSharedPreferences("sg", Context.MODE_PRIVATE); }
    static String phone(Context c) { return p(c).getString("phone", ""); }
    static void setPhone(Context c, String s) { p(c).edit().putString("phone", s).apply(); }
    static boolean unlocked(Context c) { return System.currentTimeMillis() < p(c).getLong("until", 0); }
    static void unlock(Context c) { p(c).edit().putLong("until", System.currentTimeMillis() + UNLOCK_MS).apply(); }
    static void lock(Context c) { p(c).edit().putLong("until", 0).apply(); }
    static void setOtp(Context c, String o) { p(c).edit().putString("otp", o).putLong("otpUntil", System.currentTimeMillis() + OTP_MS).apply(); }
    static boolean otpValid(Context c) { return System.currentTimeMillis() < p(c).getLong("otpUntil", 0); }
    static String otp(Context c) { return p(c).getString("otp", ""); }
    static void clearOtp(Context c) { p(c).edit().remove("otp").putLong("otpUntil", 0).apply(); }
}
