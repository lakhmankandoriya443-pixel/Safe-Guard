package com.example.settingsblocker;
import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
public class AdminReceiver extends DeviceAdminReceiver {
    @Override public CharSequence onDisableRequested(Context c, Intent i) {
        return "Isse band karne par adult content protection hat jayega.";
    }
}
