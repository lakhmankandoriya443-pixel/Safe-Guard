package com.example.settingsblocker;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.widget.TextView;
public class BlockActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setText("Blocked\n\nYe content tumhare liye nahi hai. Apna time kisi achhi cheez me lagao.");
        t.setTextSize(20); t.setGravity(Gravity.CENTER); t.setTextColor(Color.WHITE);
        t.setBackgroundColor(Color.parseColor("#B71C1C")); t.setPadding(60, 60, 60, 60);
        setContentView(t);
        new Handler().postDelayed(this::finish, 2500);
    }
}
