package com.example.settingsblocker;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.*;
import java.security.SecureRandom;

public class OtpActivity extends Activity {
    EditText in; TextView msg;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Prefs.phone(this).isEmpty()) { finish(); return; }
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(48, 120, 48, 48);
        TextView h = new TextView(this); h.setTextSize(22); h.setText("Settings locked hai"); l.addView(h);
        msg = new TextView(this); msg.setPadding(0, 24, 0, 24); l.addView(msg);
        in = new EditText(this); in.setHint("6 digit OTP"); in.setInputType(InputType.TYPE_CLASS_NUMBER); l.addView(in);
        Button ok = new Button(this); ok.setText("Unlock");
        ok.setOnClickListener(v -> verify()); l.addView(ok);
        Button re = new Button(this); re.setText("OTP dobara bhejo");
        re.setOnClickListener(v -> send()); l.addView(re);
        setContentView(l);
        if (!Prefs.otpValid(this)) send();
        else msg.setText("OTP bhai ke number par bheja ja chuka hai. Wahi se maango.");
    }
    void send() {
        String code = String.format("%06d", new SecureRandom().nextInt(1000000));
        Prefs.setOtp(this, code);
        try {
            SmsManager sm = Build.VERSION.SDK_INT >= 31 ? getSystemService(SmsManager.class) : SmsManager.getDefault();
            sm.sendTextMessage(Prefs.phone(this), null,
                "Safe Guard OTP: " + code + ". Sirf tab do jab kaam sach me zaroori ho.", null, null);
            msg.setText("OTP bhai ke number par bhej diya. Unse maango.");
        } catch (Exception ex) {
            msg.setText("SMS nahi gaya. SIM / SMS permission check karo.");
        }
    }
    void verify() {
        String s = in.getText().toString().trim();
        if (Prefs.otpValid(this) && !Prefs.otp(this).isEmpty() && s.equals(Prefs.otp(this))) {
            Prefs.unlock(this); Prefs.clearOtp(this);
            startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            finish();
        } else Toast.makeText(this, "Galat ya expire OTP", Toast.LENGTH_SHORT).show();
    }
    @Override public void onBackPressed() {
        startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }
}
