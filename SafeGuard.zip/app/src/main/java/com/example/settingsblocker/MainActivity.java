package com.example.settingsblocker;
import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.*;

public class MainActivity extends Activity {
    @Override protected void onResume() { super.onResume(); build(); }

    Button btn(String t) { Button b = new Button(this); b.setText(t); return b; }

    void build() {
        boolean hasPhone = !Prefs.phone(this).isEmpty();
        boolean canEdit = !hasPhone || Prefs.unlocked(this);
        boolean admin = ((DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE))
            .isAdminActive(new ComponentName(this, AdminReceiver.class));
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean acc = en != null && en.contains(getPackageName() + "/" + GuardService.class.getName());
        boolean sms = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(48, 100, 48, 48);
        TextView h = new TextView(this); h.setTextSize(24); h.setText("Safe Guard"); l.addView(h);
        TextView st = new TextView(this); st.setPadding(0, 24, 0, 24);
        st.setText("Device admin: " + (admin ? "ON" : "OFF") + "\nAccessibility: " + (acc ? "ON" : "OFF")
            + "\nSMS permission: " + (sms ? "OK" : "NAHI") + "\nBhai ka number: " + (hasPhone ? "set (locked)" : "NAHI"));
        l.addView(st);

        EditText ph = new EditText(this); ph.setHint("Bhai ka phone number");
        ph.setInputType(InputType.TYPE_CLASS_PHONE); ph.setText(Prefs.phone(this)); ph.setEnabled(canEdit); l.addView(ph);
        Button save = btn("Number save karo"); save.setEnabled(canEdit);
        save.setOnClickListener(v -> {
            String s = ph.getText().toString().trim();
            if (s.length() < 10) { Toast.makeText(this, "Sahi number daalo", Toast.LENGTH_SHORT).show(); return; }
            Prefs.setPhone(this, s); Prefs.lock(this); build();
        });
        l.addView(save);

        Button b1 = btn("1. Device admin ON karo (uninstall rokne ke liye)");
        b1.setOnClickListener(v -> startActivity(new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class))));
        l.addView(b1);
        Button b2 = btn("2. SMS permission do");
        b2.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1));
        l.addView(b2);
        Button b3 = btn("3. Accessibility ON karo (Safe Guard chuno)");
        b3.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        l.addView(b3);
        TextView n = new TextView(this); n.setPadding(0, 24, 0, 0);
        n.setText("Sabse last me upar bhai ka number save karo. Uske baad Settings bina OTP ke nahi khulegi.");
        l.addView(n);
        if (hasPhone && !Prefs.unlocked(this)) {
            Button u = btn("OTP se unlock karo");
            u.setOnClickListener(v -> startActivity(new Intent(this, OtpActivity.class)));
            l.addView(u);
        }
        ScrollView sv = new ScrollView(this); sv.addView(l); setContentView(sv);
    }
}
